package com.example.usersapp;

public class User {
    public String _name ;
    public String _email;
    public String _gender;
    public String _imageUrl;
    public String _age;

    public String get_name() { return _name; }

    public void set_name(String _name) { this._name = _name; }

    public String get_email() { return _email; }

    public void set_email(String _email) { this._email = _email; }

    public String get_gender() { return _gender; }

    public void set_gender(String _gender) { this._gender = _gender; }

    public String get_imageUrl() { return _imageUrl; }

    public void set_imageUrl(String _imageUrl) { this._imageUrl = _imageUrl; }

    public String get_age() { return _age; }

    public void set_age(String _age) { this._age = _age; }
}
